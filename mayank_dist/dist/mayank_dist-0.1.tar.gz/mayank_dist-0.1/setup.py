from setuptools import setup

setup(name='mayank_dist',
      version='0.1',
      description='Gaussian distributions',
      packages=['mayank_dist'],
      zip_safe=False)
